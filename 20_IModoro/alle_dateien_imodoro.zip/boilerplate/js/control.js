// **********************
// *      index         *
// **********************

// Wenn das Dokument geladen wurde, führe loadFunc() aus
document.addEventListener('DOMContentLoaded', loadFunc);

// Globale Variablen
let timer;
let name;
let beschreibung;

// Führe aus, sobald die Webseite fertig gealden hat
function loadFunc() {
    
}

